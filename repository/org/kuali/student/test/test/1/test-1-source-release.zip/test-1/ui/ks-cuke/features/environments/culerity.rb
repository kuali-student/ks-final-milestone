Webrat.configure do |config|
  config.application_framework = :external
end