require 'savon'

Savon::Request.log = false
