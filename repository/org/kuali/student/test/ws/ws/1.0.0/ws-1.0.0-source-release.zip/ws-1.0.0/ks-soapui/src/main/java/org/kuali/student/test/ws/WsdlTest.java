package org.kuali.student.test.ws;

public class WsdlTest {
}
