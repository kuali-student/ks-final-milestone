package org.kuali.core.db.torque;

public class Sequence {

	private String name;
	private String nextVal;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNextVal() {
		return nextVal;
	}
	public void setNextVal(String nextVal) {
		this.nextVal = nextVal;
	}

}
