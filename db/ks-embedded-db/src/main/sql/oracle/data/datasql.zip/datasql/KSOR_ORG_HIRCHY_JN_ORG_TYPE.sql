TRUNCATE TABLE KSOR_ORG_HIRCHY_JN_ORG_TYPE DROP STORAGE
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.CorporateEntity')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Board')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Division')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.School')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Program')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Center')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.College')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Department')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Office')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Association')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.AdvisoryGroup')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.WorkGroup')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Section')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Senate')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.Committee')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.AdhocCommittee')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Main','kuali.org.COC')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Curriculum','kuali.org.COC')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Curriculum','kuali.org.College')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Curriculum','kuali.org.Department')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Curriculum','kuali.org.Division')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Curriculum','kuali.org.Program')
/
INSERT INTO KSOR_ORG_HIRCHY_JN_ORG_TYPE (ORG_HIRCHY_ID,ORG_TYPE_ID)
  VALUES ('kuali.org.hierarchy.Curriculum','kuali.org.Senate')
/
