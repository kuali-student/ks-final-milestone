package ca.ubc.student.kuali.lum.cdm;

public class CdmConstants {
  public static final String NAMESPACE="CDM";
  public static final String COURSE_SERVICE = "courseService";
  public static final String LU_SERVICE_NAMESPACE = "http://student.kuali.org/wsdl/lu";
  public static final String LU_SERVICE = "LuService";
}
