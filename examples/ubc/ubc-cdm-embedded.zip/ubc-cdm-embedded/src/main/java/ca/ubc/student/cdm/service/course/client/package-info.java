@javax.xml.bind.annotation.XmlSchema(namespace = "http://course.server.services.cdm.student.ubc/")
package ca.ubc.student.cdm.service.course.client;
